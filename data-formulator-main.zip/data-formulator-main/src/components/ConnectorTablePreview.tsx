// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

/**
 * ConnectorTablePreview — unified preview panel for connector tables.
 *
 * Used in both:
 *  - DataSourceSidebar (Popover preview when clicking a dataset)
 *  - DBTableManager / DataLoaderForm (right-hand preview panel)
 *
 * Provides: header with name/row-count, smart filters,
 * sort controls, DataFrameTable, and Load / Already-Loaded footer.
 */

import React, { useState, useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import {
    Autocomplete,
    Box,
    Button,
    CircularProgress,
    IconButton,
    MenuItem,
    Stack,
    TextField,
    Tooltip,
    Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import RefreshIcon from '@mui/icons-material/Refresh';
import CheckIcon from '@mui/icons-material/Check';

import { DataFrameTable } from '../views/DataFrameTable';
import { fetchWithIdentity, CONNECTOR_ACTION_URLS, SourceTableRef } from '../app/utils';
import { apiRequest } from '../app/apiClient';
import { iconVar, textVar } from '../app/layout';

// ─── Types ───────────────────────────────────────────────────────────────────

export interface ColumnMeta {
    name: string;
    type: string;
    source_type?: string;
    description?: string;
    source_description?: string;
    verbose_name?: string;
    expression?: string;
}

export interface PreviewFilter {
    column: string;
    operator: string;
    value: string;
    valueTo?: string;
}

/** Coerced filter ready for the backend API. */
export interface SourceFilter {
    column: string;
    operator: string;
    value?: any;
}

export interface ConnectorTablePreviewProps {
    connectorId: string;
    sourceTable: SourceTableRef;
    displayName: string;
    pathBreadcrumb?: string;
    /** Effective table-level description shown to users. */
    tableDescription?: string;
    /** Original source-system table description (kept for compatibility). */
    sourceDescription?: string;

    columns: ColumnMeta[];
    sampleRows: Record<string, any>[];
    rowCount: number | null;
    loading: boolean;

    alreadyLoaded: boolean;

    enableFilters?: boolean;

    /** Hide the load/filter footer entirely — the preview then shows only
     *  table metadata (used when loading is driven from elsewhere, e.g. a
     *  batch action bar). */
    hideLoadActions?: boolean;

    onLoad?: (importOptions: Record<string, any>) => void;
    /** Optional: load the table into a brand-new workspace session. When
     *  provided, a secondary "Load in new session" button appears next to
     *  the primary Load button. */
    onLoadInNewSession?: (importOptions: Record<string, any>) => void;
    onUnload?: () => void;
    /** Called when the user clicks "Preview" to refresh with filters. */
    onRefreshPreview?: (rows: Record<string, any>[], columns: ColumnMeta[], rowCount: number | null) => void;
}

// ─── Filter helpers (pure functions) ─────────────────────────────────────────

export function inferInputType(pandasType: string, sourceType?: string): 'time' | 'numeric' | 'boolean' | 'select' | 'text' {
    const src = (sourceType || '').toUpperCase();
    const pd = (pandasType || '').toUpperCase();
    if (src) {
        if (src === 'TEMPORAL' || /DATE|TIME|TIMESTAMP|DATETIME/.test(src)) return 'time';
        if (src === 'NUMERIC' || /INT|FLOAT|DOUBLE|DECIMAL|BIGINT|NUMBER/.test(src)) return 'numeric';
        if (src === 'BOOLEAN' || /BOOL/.test(src)) return 'boolean';
    }
    if (/DATETIME/.test(pd)) return 'time';
    if (/INT|FLOAT/.test(pd)) return 'numeric';
    if (/BOOL/.test(pd)) return 'boolean';
    return 'select';
}

export function defaultOperatorForType(inputType: string): string {
    if (inputType === 'time') return 'BETWEEN';
    if (inputType === 'boolean') return 'EQ';
    if (inputType === 'select') return 'EQ';
    if (inputType === 'numeric') return 'EQ';
    return 'ILIKE';
}

/** Build a backend-ready filter array from the user's raw filter state. */
export function coerceFilters(filters: PreviewFilter[], columns: ColumnMeta[]): SourceFilter[] {
    return filters
        .filter(f => f.column && f.operator && (
            f.operator === 'IS_NULL' || f.operator === 'IS_NOT_NULL' ||
            (f.operator === 'BETWEEN' ? (f.value || '').trim() && (f.valueTo || '').trim() : (f.value || '').trim())
        ))
        .map(f => {
            const colMeta = columns.find(c => c.name === f.column);
            const iType = colMeta ? inferInputType(colMeta.type, colMeta.source_type) : 'text';
            if (f.operator === 'BETWEEN') {
                const v1 = iType === 'numeric' ? Number(f.value) : f.value;
                const v2 = iType === 'numeric' ? Number(f.valueTo) : f.valueTo;
                return { column: f.column, operator: f.operator, value: [v1, v2] };
            }
            if (f.operator === 'IS_NULL' || f.operator === 'IS_NOT_NULL') {
                return { column: f.column, operator: f.operator };
            }
            let val: any = f.value;
            if (iType === 'numeric' && f.value) val = Number(f.value);
            else if (iType === 'boolean') val = f.value === 'true';
            return { column: f.column, operator: f.operator, value: val };
        });
}

// ─── Component ───────────────────────────────────────────────────────────────

export const ConnectorTablePreview: React.FC<ConnectorTablePreviewProps> = ({
    connectorId,
    sourceTable,
    displayName,
    pathBreadcrumb,
    tableDescription,
    sourceDescription,
    columns,
    sampleRows,
    rowCount,
    loading,
    alreadyLoaded,
    enableFilters = true,
    hideLoadActions = false,
    onLoad,
    onLoadInNewSession,
    onUnload,
    onRefreshPreview,
}) => {
    const { t } = useTranslation();

    // Filters
    const [filters, setFilters] = useState<PreviewFilter[]>([]);
    const [filterOptionsMap, setFilterOptionsMap] = useState<Record<string, { label: string; value: any }[]>>({});
    const [filterOptionsLoading, setFilterOptionsLoading] = useState<string | null>(null);
    const [filterOptionsMore, setFilterOptionsMore] = useState<Record<string, boolean>>({});

    // Preview refresh loading (separate from parent loading)
    const [refreshing, setRefreshing] = useState(false);

    const isLoading = loading || refreshing;
    const effectiveDesc = (tableDescription || sourceDescription || '').trim();
    // Source-metadata row only renders the table-level description.
    // Per-column metadata is exposed as header tooltips on the preview table
    // (DataFrameTable.columnDescriptions) — see design-docs/23-table-description-unification.md.
    const hasMetadataRow = Boolean(effectiveDesc);

    // ── Operator definitions ─────────────────────────────────────────────

    const getOperatorsForType = useCallback((inputType: string) => {
        switch (inputType) {
            case 'boolean':
                return [
                    { value: 'EQ', label: '=' },
                    { value: 'IS_NULL', label: 'IS NULL' },
                    { value: 'IS_NOT_NULL', label: 'IS NOT NULL' },
                ];
            case 'select':
                return [
                    { value: 'EQ', label: '=' },
                    { value: 'NEQ', label: '!=' },
                    { value: 'IS_NULL', label: 'IS NULL' },
                    { value: 'IS_NOT_NULL', label: 'IS NOT NULL' },
                ];
            case 'numeric':
                return [
                    { value: 'EQ', label: '=' },
                    { value: 'GT', label: '>' },
                    { value: 'GTE', label: '>=' },
                    { value: 'LT', label: '<' },
                    { value: 'LTE', label: '<=' },
                    { value: 'BETWEEN', label: t('connectorPreview.opBetween', { defaultValue: 'BETWEEN' }) },
                    { value: 'IS_NULL', label: 'IS NULL' },
                    { value: 'IS_NOT_NULL', label: 'IS NOT NULL' },
                ];
            case 'time':
                return [
                    { value: 'BETWEEN', label: t('connectorPreview.opBetween', { defaultValue: 'BETWEEN' }) },
                    { value: 'EQ', label: '=' },
                    { value: 'GT', label: '>' },
                    { value: 'GTE', label: '>=' },
                    { value: 'LT', label: '<' },
                    { value: 'LTE', label: '<=' },
                    { value: 'IS_NULL', label: 'IS NULL' },
                    { value: 'IS_NOT_NULL', label: 'IS NOT NULL' },
                ];
            default:
                return [
                    { value: 'ILIKE', label: t('connectorPreview.opContains', { defaultValue: 'CONTAINS' }) },
                    { value: 'EQ', label: '=' },
                    { value: 'NEQ', label: '!=' },
                    { value: 'IS_NULL', label: 'IS NULL' },
                    { value: 'IS_NOT_NULL', label: 'IS NOT NULL' },
                ];
        }
    }, [t]);

    // ── Autocomplete values ──────────────────────────────────────────────

    const loadFilterOptions = useCallback(async (columnName: string, keyword = '') => {
        const cacheKey = `${connectorId}:${sourceTable.id}:${columnName}`;
        setFilterOptionsLoading(cacheKey);
        try {
            const { data } = await apiRequest<any>(CONNECTOR_ACTION_URLS.COLUMN_VALUES, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    connector_id: connectorId,
                    source_table: sourceTable,
                    column_name: columnName,
                    keyword: keyword.trim(),
                    limit: 50,
                }),
            });
            setFilterOptionsMap(prev => ({ ...prev, [cacheKey]: data.options || [] }));
            setFilterOptionsMore(prev => ({ ...prev, [cacheKey]: !!data.has_more }));
        } catch { /* best-effort */ } finally {
            setFilterOptionsLoading(cur => cur === cacheKey ? null : cur);
        }
    }, [connectorId, sourceTable]);

    // ── Refresh preview with filters ─────────────────────────────────────

    const handleRefreshPreview = useCallback(() => {
        const validFilters = coerceFilters(filters, columns);
        const opts: Record<string, any> = { size: 10 };
        if (validFilters.length > 0) opts.source_filters = validFilters;
        setRefreshing(true);
        apiRequest<any>(CONNECTOR_ACTION_URLS.PREVIEW_DATA, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                connector_id: connectorId,
                source_table: sourceTable,
                import_options: opts,
            }),
        })
            .then(({ data }) => {
                if (data.columns && data.rows) {
                    onRefreshPreview?.(data.rows, data.columns, data.total_row_count ?? null);
                }
            })
            .catch(() => { /* best-effort */ })
            .finally(() => setRefreshing(false));
    }, [filters, columns, connectorId, sourceTable, onRefreshPreview]);

    // ── Load handler ─────────────────────────────────────────────────────

    const handleLoad = useCallback(() => {
        const opts: Record<string, any> = {};
        const validFilters = coerceFilters(filters, columns);
        if (validFilters.length > 0) {
            opts.source_filters = validFilters;
        }
        onLoad?.(opts);
    }, [filters, columns, onLoad]);

    const handleLoadInNewSession = useCallback(() => {
        if (!onLoadInNewSession) return;
        const opts: Record<string, any> = {};
        const validFilters = coerceFilters(filters, columns);
        if (validFilters.length > 0) {
            opts.source_filters = validFilters;
        }
        onLoadInNewSession(opts);
    }, [filters, columns, onLoadInNewSession]);

    // ── Shared styles ────────────────────────────────────────────────────

    const inputSx = {
        '& .MuiInputBase-root': { fontSize: textVar.xs, height: 26 },
        '& .MuiInputBase-input': { py: 0.25, px: 0.75 },
    };

    // ── Render value control for a filter row ────────────────────────────

    const renderValueControl = (f: PreviewFilter, idx: number, inputType: string) => {
        const noValue = f.operator === 'IS_NULL' || f.operator === 'IS_NOT_NULL';
        const isBetween = f.operator === 'BETWEEN';

        if (noValue) {
            return (
                <Typography variant="caption" sx={{ color: 'text.disabled', fontSize: textVar.xxs, alignSelf: 'center' }}>
                    {t('connectorPreview.noValueNeeded', { defaultValue: 'No value needed' })}
                </Typography>
            );
        }
        if (inputType === 'boolean') {
            return (
                <TextField
                    select size="small" value={f.value || ''}
                    onChange={(e) => setFilters(prev => prev.map((r, i) => i === idx ? { ...r, value: e.target.value } : r))}
                    sx={{ width: 110, ...inputSx }}
                    slotProps={{ select: { displayEmpty: true } }}
                >
                    <MenuItem value="" sx={{ fontSize: textVar.xs, color: 'text.disabled' }}><em>—</em></MenuItem>
                    <MenuItem value="true" sx={{ fontSize: textVar.xs }}>True</MenuItem>
                    <MenuItem value="false" sx={{ fontSize: textVar.xs }}>False</MenuItem>
                </TextField>
            );
        }
        if (inputType === 'select' && f.column) {
            const cacheKey = `${connectorId}:${sourceTable.id}:${f.column}`;
            const hasTruncation = filterOptionsMore[cacheKey];
            return (
                <Tooltip
                    title={hasTruncation ? t('connectorPreview.filterOptionsTruncated', { defaultValue: 'Results truncated, type to narrow' }) : ''}
                    placement="top"
                >
                <Box sx={{ width: 200 }}>
                    <Autocomplete
                        freeSolo size="small"
                        options={filterOptionsMap[cacheKey] || []}
                        value={f.value || null}
                        loading={filterOptionsLoading === cacheKey}
                        filterOptions={(opts) => opts}
                        getOptionLabel={(opt) => typeof opt === 'string' ? opt : (opt as any).label || String((opt as any).value)}
                        isOptionEqualToValue={(opt, val) => String(typeof opt === 'string' ? opt : (opt as any).value) === String(typeof val === 'string' ? val : (val as any).value)}
                        onChange={(_, val) => {
                            const newVal = val == null ? '' : typeof val === 'string' ? val : String((val as any).value);
                            setFilters(prev => prev.map((r, i) => i === idx ? { ...r, value: newVal } : r));
                        }}
                        onInputChange={(_, val, reason) => {
                            if (reason === 'input') {
                                setFilters(prev => prev.map((r, i) => i === idx ? { ...r, value: val } : r));
                            }
                        }}
                        renderInput={(params) => (
                            <TextField
                                {...params} size="small"
                                placeholder={t('connectorPreview.filterValueSearch', { defaultValue: 'Enter & search' })}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        e.preventDefault();
                                        loadFilterOptions(f.column, f.value || '');
                                    }
                                }}
                                sx={{ ...inputSx, '& .MuiOutlinedInput-root': { fontSize: textVar.xs, height: 26, py: 0 } }}
                            />
                        )}
                        slotProps={{ listbox: { sx: { fontSize: textVar.xs } } }}
                    />
                </Box>
                </Tooltip>
            );
        }
        if (inputType === 'time') {
            const dateSx = {
                '& .MuiInputBase-root': { fontSize: textVar.xs, height: 28 },
                '& .MuiInputBase-input': { py: 0.25, px: 0.75 },
                '& .MuiInputBase-input::-webkit-calendar-picker-indicator': { cursor: 'pointer', opacity: 0.6 },
            };
            return (
                <Stack direction="row" spacing={0.5} sx={{ width: isBetween ? 280 : 160 }}>
                    <TextField
                        size="small" type="date" value={f.value || ''} placeholder="YYYY-MM-DD"
                        onChange={(e) => setFilters(prev => prev.map((r, i) => i === idx ? { ...r, value: e.target.value } : r))}
                        slotProps={{ inputLabel: { shrink: true } }}
                        sx={{ flex: 1, ...dateSx }}
                    />
                    {isBetween && (
                        <TextField
                            size="small" type="date" value={f.valueTo || ''} placeholder="YYYY-MM-DD"
                            onChange={(e) => setFilters(prev => prev.map((r, i) => i === idx ? { ...r, valueTo: e.target.value } : r))}
                            slotProps={{ inputLabel: { shrink: true } }}
                            sx={{ flex: 1, ...dateSx }}
                        />
                    )}
                </Stack>
            );
        }
        if (inputType === 'numeric') {
            return (
                <Stack direction="row" spacing={0.5} sx={{ width: isBetween ? 220 : 120 }}>
                    <TextField
                        size="small" type="number" value={f.value || ''}
                        placeholder={t('connectorPreview.filterValue', { defaultValue: 'Value' })}
                        onChange={(e) => setFilters(prev => prev.map((r, i) => i === idx ? { ...r, value: e.target.value } : r))}
                        sx={{ flex: 1, ...inputSx }}
                    />
                    {isBetween && (
                        <TextField
                            size="small" type="number" value={f.valueTo || ''}
                            placeholder={t('connectorPreview.filterValueTo', { defaultValue: 'To' })}
                            onChange={(e) => setFilters(prev => prev.map((r, i) => i === idx ? { ...r, valueTo: e.target.value } : r))}
                            sx={{ flex: 1, ...inputSx }}
                        />
                    )}
                </Stack>
            );
        }
        return (
            <TextField
                size="small" value={f.value || ''}
                placeholder={t('connectorPreview.filterValue', { defaultValue: 'Value' })}
                onChange={(e) => setFilters(prev => prev.map((r, i) => i === idx ? { ...r, value: e.target.value } : r))}
                sx={{ width: 200, ...inputSx }}
            />
        );
    };

    // ── JSX ──────────────────────────────────────────────────────────────

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
            {/* Header — name + row count */}
            <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1, mb: 0.5, flexShrink: 0 }}>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography sx={{ fontSize: textVar.lg, fontWeight: 600 }} noWrap>{displayName}</Typography>
                    {pathBreadcrumb && (
                        <Typography sx={{ fontSize: textVar.xs, color: 'text.disabled' }} noWrap>{pathBreadcrumb}</Typography>
                    )}
                    {(() => {
                        // Row-count line — ALWAYS rendered as a single
                        // `Typography` so the header height is identical
                        // across loading/loaded states and across tables
                        // (no wrap, no conditional rendering, no visibility
                        // toggling between elements).
                        //
                        // `rowCount` is shown only when reliable as the
                        // true table total:
                        //   - it exceeds the preview sample (more rows
                        //     exist than we returned), OR
                        //   - the sample is shorter than the preview cap
                        //     of 10 (we exhausted the table).
                        // Otherwise we fall back to the "Preview shows
                        // first N rows" notice, or — during loading — a
                        // hidden non-breaking space placeholder that
                        // reserves the same line height.
                        const PREVIEW_CAP = 10;
                        const sampleLen = sampleRows.length;
                        const totalReliable = rowCount != null && (rowCount > sampleLen || sampleLen < PREVIEW_CAP);
                        const previewNotice = t('connectorPreview.previewRowsNotice', {
                            count: sampleLen,
                            defaultValue: `Preview shows first ${sampleLen} rows only`,
                        });

                        let content: React.ReactNode;
                        let hidden = false;
                        if (totalReliable) {
                            content = (
                                <>
                                    {t('connectorPreview.rowCount', {
                                        count: Number(rowCount).toLocaleString(),
                                        defaultValue: '{{count}} rows',
                                    })}
                                    {sampleLen > 0 && rowCount! > sampleLen && (
                                        <Box component="span" sx={{ opacity: 0.7, ml: 0.5 }}>
                                            ({previewNotice})
                                        </Box>
                                    )}
                                </>
                            );
                        } else if (sampleLen > 0) {
                            content = previewNotice;
                        } else {
                            content = '\u00A0';
                            hidden = true;
                        }

                        return (
                            <Typography
                                noWrap
                                sx={{
                                    fontSize: textVar.xs,
                                    color: 'text.disabled',
                                    visibility: hidden ? 'hidden' : 'visible',
                                }}
                            >
                                {content}
                            </Typography>
                        );
                    })()}
                </Box>
            </Box>

            {hasMetadataRow && (
                <Box sx={{
                    flexShrink: 0,
                    mt: 0.5, mb: 0.75,
                    // Cap the metadata block so a very long description
                    // doesn't push the table off-screen. Scrolls within.
                    maxHeight: 120,
                    overflowY: 'auto',
                }}>
                    <Typography
                        sx={{
                            fontSize: textVar.xs,
                            color: 'text.primary',
                            whiteSpace: 'pre-wrap',
                            wordBreak: 'break-word',
                        }}
                    >
                        {effectiveDesc}
                    </Typography>
                </Box>
            )}

            {/* Preview table — uses a *fixed* height (not minHeight) so the
                section is identical across all tables and across the
                loading→loaded transition. The value (290px) covers the
                worst case: 10 compact rows (~220) + header (~22) + the
                "…" continuation row that DataFrameTable renders when the
                full table exceeds 10 rows (~22) + horizontal scrollbar
                lane for wide tables (~15) + cell borders (~6).

                Overflow is *horizontal only*: content is intrinsically
                capped at 10 rows + header + "…" row, so a vertical
                scrollbar would never represent real overflow — it would
                only appear as a side effect of the horizontal scrollbar
                eating into the height. `overflowY: hidden` keeps that
                from happening. */}
            <Box sx={{
                flex: '0 0 auto',
                height: 290,
                position: 'relative',
                overflowX: 'auto',
                overflowY: 'hidden',
            }}>
                {isLoading && sampleRows.length === 0 ? (
                    <Box sx={{
                        position: 'absolute', inset: 0,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                        <CircularProgress size={18} thickness={4} sx={{ color: 'text.disabled', opacity: 0.6 }} />
                    </Box>
                ) : sampleRows.length > 0 ? (
                    <DataFrameTable
                        columns={columns.map(c => c.name)}
                        rows={sampleRows}
                        totalRows={rowCount ?? undefined}
                        maxColumns={20}
                        maxRows={10}
                        fontSize={11}
                        headerFontSize={10}
                        showIndex
                        autoWidth
                        columnDescriptions={columns.reduce<Record<string, string>>((acc, c) => {
                            if (c.description) acc[c.name] = c.description;
                            return acc;
                        }, {})}
                    />
                ) : columns.length > 0 && filters.length > 0 ? (
                    <Typography sx={{ fontSize: textVar.sm, color: 'text.disabled', fontStyle: 'italic', py: 2, textAlign: 'center' }}>
                        {t('connectorPreview.noMatchingRows', { defaultValue: 'No rows match the current filters' })}
                    </Typography>
                ) : (
                    <Typography sx={{ fontSize: textVar.sm, color: 'text.disabled', fontStyle: 'italic', py: 2, textAlign: 'center' }}>
                        {t('connectorPreview.noPreviewAvailable', { defaultValue: 'No preview available' })}
                    </Typography>
                )}
            </Box>

            {/* Filter conditions — sits *below* the preview, next to the
                Preview-refresh button so editing filters and applying them
                happen in the same place.

                Rendered as soon as `enableFilters` is on and the table
                isn't already loaded — we *don't* gate on `columns.length`
                so the filter row reserves its own space during loading
                (otherwise the popover would grow when columns arrive).
                The Add-filter button is disabled until columns are known
                and the Preview button uses the same isLoading guard. */}
            {enableFilters && !alreadyLoaded && !hideLoadActions && (
                <Box sx={{ mt: 0.75, mb: 0.5, flexShrink: 0 }}>
                    {filters.map((f, idx) => {
                        const colMeta = columns.find(c => c.name === f.column);
                        const inputType = colMeta ? inferInputType(colMeta.type, colMeta.source_type) : 'text';
                        const operators = f.column ? getOperatorsForType(inputType) : getOperatorsForType('text');

                        return (
                            <Box key={idx} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.5, maxWidth: 600 }}>
                                <TextField
                                    select size="small" value={f.column}
                                    onChange={(e) => {
                                        const newCol = e.target.value;
                                        const newMeta = columns.find(c => c.name === newCol);
                                        const newType = newMeta ? inferInputType(newMeta.type, newMeta.source_type) : 'text';
                                        const newOps = getOperatorsForType(newType);
                                        const opValid = newOps.some(op => op.value === f.operator);
                                        setFilters(prev => prev.map((r, i) => i === idx ? {
                                            ...r,
                                            column: newCol,
                                            operator: opValid ? r.operator : defaultOperatorForType(newType),
                                            value: '', valueTo: '',
                                        } : r));
                                    }}
                                    slotProps={{ select: { displayEmpty: true } }}
                                    sx={{ minWidth: 130, '& .MuiInputBase-root': { fontSize: textVar.xs, height: 26 }, '& .MuiSelect-select': { py: 0.1, px: 0.75 } }}
                                >
                                    <MenuItem value="" disabled sx={{ fontSize: textVar.xs, color: 'text.disabled' }}>
                                        <em>{t('connectorPreview.filterColumn', { defaultValue: 'Column' })}</em>
                                    </MenuItem>
                                    {columns.map(c => (
                                        <MenuItem key={c.name} value={c.name} sx={{ fontSize: textVar.xs }}>
                                            <Tooltip title={c.description || ''} placement="right" enterDelay={400} disableHoverListener={!c.description}>
                                                <span>{c.name}</span>
                                            </Tooltip>
                                        </MenuItem>
                                    ))}
                                </TextField>
                                <TextField
                                    select size="small" value={f.operator}
                                    onChange={(e) => setFilters(prev => prev.map((r, i) => i === idx ? { ...r, operator: e.target.value, value: '', valueTo: '' } : r))}
                                    sx={{ minWidth: 100, '& .MuiInputBase-root': { fontSize: textVar.xs, height: 26 }, '& .MuiSelect-select': { py: 0.1, px: 0.75 } }}
                                >
                                    {operators.map(op => (
                                        <MenuItem key={op.value} value={op.value} sx={{ fontSize: textVar.xs }}>{op.label}</MenuItem>
                                    ))}
                                </TextField>
                                {renderValueControl(f, idx, inputType)}
                                <IconButton size="small" onClick={() => setFilters(prev => prev.filter((_, i) => i !== idx))}
                                    sx={{ p: 0.25, color: 'text.disabled', '&:hover': { color: 'error.main' } }}>
                                    <CloseIcon sx={{ fontSize: iconVar.sm }} />
                                </IconButton>
                            </Box>
                        );
                    })}
                    <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.5 }}>
                        <Button
                            size="small" startIcon={<AddIcon sx={{ fontSize: iconVar.sm }} />}
                            disabled={columns.length === 0}
                            onClick={() => setFilters(prev => [...prev, { column: '', operator: 'EQ', value: '' }])}
                            sx={{ textTransform: 'none', fontSize: textVar.xs, px: 1, minHeight: 0, height: 24, color: 'text.secondary' }}
                        >
                            {t('connectorPreview.addFilter', { defaultValue: 'Add filter' })}
                        </Button>
                        <Button
                            variant="outlined" size="small"
                            startIcon={<RefreshIcon sx={{ fontSize: iconVar.sm }} />}
                            disabled={isLoading || columns.length === 0}
                            onClick={handleRefreshPreview}
                            sx={{ textTransform: 'none', fontSize: textVar.xs, px: 1, minHeight: 0, height: 24 }}
                        >
                            {t('connectorPreview.refreshPreview', { defaultValue: 'Preview' })}
                        </Button>
                    </Box>
                </Box>
            )}

            {/* Footer — load buttons (hidden when loading is driven externally) */}
            {!hideLoadActions && (
            <Box sx={{ mt: 1, pt: 1, flexShrink: 0, borderTop: '1px solid', borderColor: 'divider', display: 'flex', flexDirection: 'column', gap: 1 }}>
                {alreadyLoaded ? (
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Button
                            variant="outlined" size="small" disabled
                            startIcon={<CheckIcon sx={{ fontSize: iconVar.sm }} />}
                            sx={{
                                textTransform: 'none', fontSize: textVar.sm, px: 2, height: 30,
                                color: 'success.main', borderColor: 'success.main',
                                '&.Mui-disabled': { color: 'success.main', borderColor: 'success.main', opacity: 0.8 },
                            }}
                        >
                            {t('connectorPreview.loaded', { defaultValue: 'Loaded' })}
                        </Button>
                        {onUnload && (
                            <Button
                                variant="text" size="small" onClick={onUnload}
                                sx={{
                                    textTransform: 'none', fontSize: textVar.xs, px: 1, minWidth: 0, height: 28, color: 'text.secondary',
                                    '&:hover': { color: 'error.main', backgroundColor: 'rgba(211,47,47,0.04)' },
                                }}
                            >
                                {t('connectorPreview.unload', { defaultValue: 'Unload' })}
                            </Button>
                        )}
                    </Box>
                ) : (
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                        <Box sx={{ flex: 1 }} />
                        {onLoadInNewSession && (
                            <Button
                                variant="outlined" size="small"
                                disabled={isLoading}
                                onClick={handleLoadInNewSession}
                                sx={{ textTransform: 'none', fontSize: textVar.sm, px: 2, height: 30, flexShrink: 0 }}
                            >
                                {t('connectorPreview.loadInNewSession', { defaultValue: 'Load in new session' })}
                            </Button>
                        )}
                        <Button
                            variant="contained" size="small"
                            disabled={isLoading}
                            onClick={handleLoad}
                            sx={{ textTransform: 'none', fontSize: textVar.sm, px: 3, height: 30, flexShrink: 0 }}
                        >
                            {t('connectorPreview.loadTable', { defaultValue: 'Load Table' })}
                        </Button>
                    </Box>
                )}
            </Box>
            )}
        </Box>
    );
};

export default ConnectorTablePreview;
