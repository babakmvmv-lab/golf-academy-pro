// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

import { useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { DataFormulatorState, dfActions, dfSelectors } from './dfSlice';
import { getUrls } from './utils';
import { apiRequest } from './apiClient';
import { updateWorkspaceMeta } from './workspaceService';
import { AppDispatch } from './store';

export function isUntitledWorkspaceName(displayName: string | undefined): boolean {
    return displayName === 'Untitled Session';
}

/**
 * Auto-names a workspace once it holds something worth naming — a loaded
 * table or a first exchange with the agent — if it still has its placeholder
 * name.
 *
 * Calls the LLM to generate a short display name based on
 * table names and the first user query (if any).
 */
export function useWorkspaceAutoName() {
    const dispatch = useDispatch<AppDispatch>();
    const activeWorkspace = useSelector((state: DataFormulatorState) => state.activeWorkspace);
    const tables = useSelector(dfSelectors.getAllTables);
    const draftNodes = useSelector((state: DataFormulatorState) => state.draftNodes);
    const textTurns = useSelector((state: DataFormulatorState) => state.textTurns);
    const models = useSelector(dfSelectors.getAllModels);
    const selectedModelId = useSelector((state: DataFormulatorState) => state.selectedModelId);
    const calledRef = useRef(false);
    const lastWsIdRef = useRef<string | null>(null);

    useEffect(() => {
        // Reset when workspace changes
        if (activeWorkspace?.id !== lastWsIdRef.current) {
            calledRef.current = false;
            lastWsIdRef.current = activeWorkspace?.id ?? null;
        }

        // Only auto-name once per workspace
        if (calledRef.current) return;

        // Need: an active workspace, a model, and enough substance to name.
        // A session can be conversation-only, so a first exchange counts too.
        if (!activeWorkspace) return;
        if (tables.length === 0 && textTurns.length === 0) return;
        if (!selectedModelId) return;

        // Only auto-name if the display name is still the placeholder
        if (!isUntitledWorkspaceName(activeWorkspace.displayName)) return;

        const model = models.find(m => m.id === selectedModelId);
        if (!model) return;

        calledRef.current = true;

        // Gather context
        const tableNames = tables.map(t => t.displayId || t.id);
        // The first user prompt, preferring turns: a draft is deleted when its
        // run completes, so its interaction log may already be gone.
        const firstTurnPrompt = [...textTurns]
            .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0))
            .map(turn => turn.prompt)
            .find(prompt => !!prompt);
        const firstInteraction = draftNodes
            .flatMap(n => n.derive?.trigger?.interaction || [])
            .find(entry => entry.from === 'user' && (entry.role === 'prompt' || entry.role === 'instruction'));
        const firstQuery = firstTurnPrompt || firstInteraction?.content || '';

        const wsId = activeWorkspace.id;

        (async () => {
            try {
                const { data } = await apiRequest<{ display_name: string }>(getUrls().WORKSPACE_NAME, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        model: model,
                        context: {
                            tables: tableNames,
                            userQuery: firstQuery,
                        },
                    }),
                });
                if (data.display_name) {
                    dispatch(dfActions.setActiveWorkspace({ id: wsId, displayName: data.display_name }));
                    updateWorkspaceMeta(wsId, data.display_name).catch(() => {});
                }
            } catch (e) {
                // Best-effort: keep the timestamp name if auto-naming fails
                console.warn('[auto-name] failed:', e);
            }
        })();
    }, [activeWorkspace, tables.length, selectedModelId, draftNodes.length, textTurns.length]);
}
